package com.smhrd.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.smhrd.command.Command;
import com.smhrd.model.CalendarDAO;
import com.smhrd.model.MemberDAO;

public class CalendarDeleteService implements Command {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("[CalendarDeleteService]");


		// 데이터 받아오기
		String edit_start = request.getParameter("edit_start").substring(0, 11);
		String id = request.getParameter("id");
		System.out.println("edit_start:"+edit_start);
		System.out.println("id:"+id);
		// deleteMember
		int row = new CalendarDAO().deleteCalendar(edit_start);

		if (row == 1) {
			System.out.println("삭제 성공");
		} else {
			System.out.println("삭제 실패");
		}
		
		
		return "../calendar/calendar_index.jsp";
	}
}
