package com.smhrd.controller;

import java.sql.Date;
import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smhrd.command.Command;
import com.smhrd.model.CalendarDAO;
import com.smhrd.model.CalendarDTO;
import com.smhrd.model.MemberDAO;
import com.smhrd.model.MemberDTO;

public class CalendarService implements Command {

	public String excute(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("[저장하는곳]");

		// 2. 데이터 받아오기
		String id = request.getParameter("id");
		String calendarDateStart =request.getParameter("edit_start").substring(0, 11); 
		String calendarDateFinish = request.getParameter("edit_end").substring(0, 11); 
		String color = request.getParameter("color");
		String exercise = request.getParameter("exercise");
		String memo = request.getParameter("edit_title");

		System.out.println("id:" + id);
		System.out.println("exercise:" + exercise);
		System.out.println("calendarDateStart:" + calendarDateStart);
		System.out.println("calendarDateFinish:" + calendarDateFinish);
		System.out.println("color:" + color);
		System.out.println("memo:" + memo);

		// 3.DTO로 묶기

		CalendarDTO dto = new CalendarDTO(null,id, calendarDateStart, calendarDateFinish,color,exercise, memo);
		// db접속 확인하러 가기

		// 4. 메소드 호출
		int cal = new CalendarDAO().insertCalendar(dto);

		// 5.실행결과 확인하기
		
		if (cal > 0) {
			System.out.println("삽입 성공");
			HttpSession session = request.getSession();
			session.setAttribute("cal", cal);
			
		} else {
			System.out.println("삽입 실패");

		}

		return " /calendar/calendar_index.jsp";
	}
}
