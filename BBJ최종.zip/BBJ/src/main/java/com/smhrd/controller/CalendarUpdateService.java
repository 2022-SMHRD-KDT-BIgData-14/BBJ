package com.smhrd.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smhrd.command.Command;
import com.smhrd.model.CalendarDAO;
import com.smhrd.model.CalendarDTO;

public class CalendarUpdateService implements Command {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response) {

		System.out.println("[CalUpdateService]");

		// 2. 데이터 받아오기
		String id = request.getParameter("id");
		String calendarDateStart = request.getParameter("edit_start").substring(0, 11);
		String calendarDateFinish = request.getParameter("edit_end").substring(0, 11);
		String color = request.getParameter("color");
		String exercise = request.getParameter("exercise");
		String memo = request.getParameter("edit_title");

		System.out.println("id:" + id);
		System.out.println("exercise:" + exercise);
		System.out.println("calendarDateStart:" + calendarDateStart);
		System.out.println("calendarDateFinish:" + calendarDateFinish);
		System.out.println("color:" + color);
		System.out.println("memo:" + memo);
		// 3.DTO로 묶기
		CalendarDTO dto = new CalendarDTO(null, id, calendarDateStart, calendarDateFinish, color, null, memo);

		// db접속 확인하러 가기

		// 4. update 메소드 호출
		int row = new CalendarDAO().CalendarUpdate(dto);
		String moveURL = null;
		// 5. 실핼 결과 확인
		if (row == 1) {
			System.out.println("수정 성공");
			HttpSession session = request.getSession();
			session.setAttribute("", dto);
			moveURL = "/calendar/calendar_index.jsp";
		} else {
			System.out.println("수정 실패");
			moveURL = "/calendar/calendar_index.jsp";
		}
		return moveURL;

	}

}
