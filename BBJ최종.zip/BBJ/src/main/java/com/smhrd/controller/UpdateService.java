package com.smhrd.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smhrd.command.Command;
import com.smhrd.model.MemberDAO;
import com.smhrd.model.MemberDTO;

public class UpdateService implements Command {

	@Override
	public String excute(HttpServletRequest request, HttpServletResponse response){
	
	System.out.println("[UpdateService]");

	
	// 2. 데이터 받아오기
	String id = request.getParameter("id");
	String pw = request.getParameter("pw");
	String name = request.getParameter("name");
	String address1 = request.getParameter("address1");
	String address2 = request.getParameter("address2");


	System.out.println("id:" + id);
	System.out.println("pw:" + pw);
	System.out.println("name:" + name);
	System.out.println("address1:" + address1);
	System.out.println("address2:" + address2);

	// 3.DTO로 묶기
	MemberDTO dto = new MemberDTO(id, pw, name, null,address1,address2);

	// db접속 확인하러 가기

	// 4. update 메소드 호출
	int row = new MemberDAO().update(dto);
	String moveURL=null;
	// 5. 실핼 결과 확인
	if (row == 1) {
		System.out.println("수정 성공");
		HttpSession session = request.getSession();
		// session에 잇는 info도 업데이트
		session.setAttribute("info", dto);
		if(id.equals("admin")) {
			moveURL="../main/admin.jsp";
		}else {
		moveURL="../main/main_index.jsp";}
	} else {
		System.out.println("수정 취소");
		moveURL="../main/main_index.jsp";
	}
	return moveURL;
	
		}
}