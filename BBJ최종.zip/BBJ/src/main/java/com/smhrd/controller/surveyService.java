package com.smhrd.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.smhrd.command.Command;
import com.smhrd.model.MemberDAO;
import com.smhrd.model.MemberDTO;

public class surveyService implements Command {
	public String excute(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("[surveyService]");
		HttpSession session = request.getSession();
		String moveURL = null;
		// 2. 데이터 받아오기
		String id= request.getParameter("id");
		String pw= request.getParameter("pw");
		String exercise= request.getParameter("exercise");
		//String name= request.getParameter("name");

		System.out.println("exercise:" + exercise);
		System.out.println("id:" + id);
		System.out.println("pw:" + pw);

		// 3.DTO로 묶기
		MemberDTO dto = new MemberDTO(id,pw,null,exercise,null,null);
		// 4. 운동 종류 소개 메소드 호출
		int row = new MemberDAO().exerciseUpdate(dto);
		//5. 실행결과
		if (row == 1) {
			System.out.println("수정 성공");
			// session에 잇는 info도 업데이트
			if(id.equals("admin")) {
				session.setAttribute("info", dto);
				
				moveURL="../survey/survey_result_basic.jsp";
			}else {
				session.setAttribute("info", dto);
				
			moveURL="../survey/survey_result_basic.jsp";}
		} else {
			System.out.println("수정 실패");
			moveURL="../main/main_index.jsp";
		}
		return moveURL;
		
			}
		
	}