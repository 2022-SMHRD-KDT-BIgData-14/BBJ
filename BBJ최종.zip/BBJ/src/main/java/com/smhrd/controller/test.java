package com.smhrd.controller;

public class test {
	public static void main(String[] args) {
		String a = "2022-07-05 10:50";
		a = a.substring(0, 11);
		System.out.println(a);
	}
}
