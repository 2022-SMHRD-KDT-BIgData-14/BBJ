package com.smhrd.model;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.smhrd.db.SqlSessionManager;

public class AcademtDAO {

	private SqlSessionFactory sqlSessionFactory = SqlSessionManager.getSqlSession();
	
	public ArrayList<AcademyDTO> Academy(String id) {
		System.out.println(id);
		System.out.println("DAO 입성");
		SqlSession session = sqlSessionFactory.openSession(true);
		ArrayList<AcademyDTO> Academy_list= (ArrayList)session.selectList("Academy", id);
		
		
		return Academy_list;
		
	
	}
	public ArrayList<AcademyDTO> croos(AcademyDTO dto) {
		
		System.out.println("DAO 입성");
		SqlSession session = sqlSessionFactory.openSession(true);
		ArrayList<AcademyDTO> croos_list= (ArrayList)session.selectList("cross", dto);
		
		
		return croos_list;
		
	}
}
