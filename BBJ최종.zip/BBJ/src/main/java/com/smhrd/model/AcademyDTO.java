package com.smhrd.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Getter
@AllArgsConstructor
@RequiredArgsConstructor	
public class AcademyDTO {
	private  String AcademyNB;
	private String Academy;
	private String Address1;
	private String Address2;
	@NonNull private String Exercise;
	@NonNull private String id;
	private  BigDecimal Latitude;
	private  BigDecimal Longitude;
	
	public AcademyDTO(String academyNB, String academy, String address1, String address2, String exercise) {
		super();
		AcademyNB = academyNB;
		Academy = academy;
		Address1 = address1;
		Address2 = address2;
		Exercise = exercise;
	}
	public AcademyDTO(String academyNB, String academy, String address1, String address2, String exercise,
			BigDecimal latitude, BigDecimal longitude) {
		super();
		AcademyNB = academyNB;
		Academy = academy;
		Address1 = address1;
		Address2 = address2;
		Exercise = exercise;
		Latitude = latitude;
		Longitude = longitude;
	}
	public AcademyDTO(String address1, String address2, @NonNull String id) {
		super();
		
		this.Address1 = address1;
		this.id = id;
	}
	
	
}


