package com.smhrd.model;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.smhrd.db.SqlSessionManager;

public class CalendarDAO {
	private SqlSessionFactory sqlSessionFactory =SqlSessionManager.getSqlSession();
	//캘린더 삽입
	public int insertCalendar(CalendarDTO dto){
		SqlSession session = sqlSessionFactory.openSession(true);
		int row= session.insert("insertCalendar",dto);
		session.close();
		
		return row;
	}
	//캘린더 조회
	public ArrayList<CalendarDTO> showCalendar(String id) {
		SqlSession session = sqlSessionFactory.openSession(true);
		ArrayList<CalendarDTO> cal_list = (ArrayList)session.selectList("showCalendar", id);
		session.close();
		
		return cal_list;
	}
	//캘린더 업데이트
		public int CalendarUpdate(CalendarDTO dto) {
			SqlSession session = sqlSessionFactory.openSession(true);//열어주기
			int row= session.update("CalendarUpdate",dto);
			session.close();
			return row;
		}
	//캘린더 삭제
		public int deleteCalendar(String edit_start) {
			SqlSession session = sqlSessionFactory.openSession(true);
			int row=session.delete("deleteCalendar",edit_start);
			session.close();
			
			return row;
		}
	
}
