package com.smhrd.model;

import java.math.BigDecimal;
import java.sql.Time;
import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
@Getter
@AllArgsConstructor
@RequiredArgsConstructor
public class CalendarDTO {
	  private BigDecimal num;
	  private String id;
	  private String calendarDateStart;
	  private String calendarDateFinish;
	  private String color;
	  private String exercise;
	  private String memo;  
}
