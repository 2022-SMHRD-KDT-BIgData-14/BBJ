package com.smhrd.model;

import java.util.ArrayList;


import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.smhrd.db.SqlSessionManager;

public class PtDAO {
	
	private	SqlSessionFactory SqlSessionFactory=SqlSessionManager.getSqlSession();

	public ArrayList<PtDTO> Pt(String id){
		System.out.println(id);		
		SqlSession session = SqlSessionFactory.openSession(true);
		
		ArrayList<PtDTO> pt_list = (ArrayList)session.selectList("Pt", id);
		
		session.close();
		
		return pt_list;
	}

}
