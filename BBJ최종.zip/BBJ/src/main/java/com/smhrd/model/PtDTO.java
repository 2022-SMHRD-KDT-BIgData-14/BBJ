package com.smhrd.model;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;


@Getter
@AllArgsConstructor


public class PtDTO {
	
	private BigDecimal ptmb;
	private String exercise;
	private String ptname;
	private String address1;
	private String address2;
	private String image;
	private String profile;
	private String id;
	
	public PtDTO(String exercise, String ptname, String address1, String address2, String image, String profile) {
		super();
		this.exercise = exercise;
		this.ptname = ptname;
		this.address1 = address1;
		this.address2 = address2;
		this.image = image;
		this.profile = profile;
	}

	public PtDTO(String exercise, String ptname, String address1, String image, String profile) {
		super();
		this.exercise = exercise;
		this.ptname = ptname;
		this.address1 = address1;
		this.image = image;
		this.profile = profile;
	}

	public PtDTO(BigDecimal ptmb, String exercise, String ptname, String address1, String address2, String image,
			String profile) {
		super();
		this.ptmb = ptmb;
		this.exercise = exercise;
		this.ptname = ptname;
		this.address1 = address1;
		this.address2 = address2;
		this.image = image;
		this.profile = profile;
	}
	
}

